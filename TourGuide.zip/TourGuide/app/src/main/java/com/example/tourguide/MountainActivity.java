package com.example.tourguide;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


public class MountainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String mountainName = getIntent().getStringExtra("mountainName");
        int imageId = getIntent().getIntExtra("imageId" ,0);
        int detailsId = getIntent().getIntExtra("detailsId" ,0);
        int nearbyId = getIntent().getIntExtra("nearbyId" ,0);
        int activityId = getIntent().getIntExtra("activityId" ,0);
        int besttimeId = getIntent().getIntExtra("besttimeId" ,0);


    }
}



