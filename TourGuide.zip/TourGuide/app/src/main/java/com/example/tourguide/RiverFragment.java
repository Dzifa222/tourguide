package com.example.tourguide;

public class RiverFragment {
}
