package com.example.tourguide;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class RiverActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String garden = getIntent().getStringExtra("riverName");
        int imageId = getIntent().getIntExtra("imageId", 0);
        int gardenDetails = getIntent().getIntExtra("riverDetails", 0);
        int gardenThingsToDo = getIntent().getIntExtra("riverThingsToDo", 0);
        int gardenTimings = getIntent().getIntExtra("riverTimings" , 0);
        int gardenEntryfee = getIntent().getIntExtra("riverEntryfee", 0);
        int gardenBestTime = getIntent().getIntExtra("riverBestTime", 0);


}}
